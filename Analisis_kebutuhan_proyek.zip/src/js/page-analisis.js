export function initAnalisis() {
  console.log("✅ Halaman Analisis aktif");

}
